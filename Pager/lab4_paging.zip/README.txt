Hello,

This attached in this zip is my lab 4 for paging.

Please ensure that the correct random-numbers.txt is in the same folder as the paging.java 
file.

Example:

lab4_folder
	- paging.java
	- random-numbers.txt

Please compile my lab on terminal as:

javac paging.java

Please run the lab with the correct format as:

Ex:

Input is Machine Size, Page Size, Size of each process, Job Mix, Number of references, Replacement algorithm, Debugging level of input

While the debugging level of input has no affect on the code, it is required for the java file to compile. It was added to maintain consistency with the consistency of the output files and the input examples listed in the specifications.

Input is 10 10 20 1 10 lru 0

java paging 10 10 20 1 10 lru 0

Thank you,
Alexander Nguyen